import { Component } from '@angular/core';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.html',
  //template: `<p>register works!</p>`, //inline html template
  styleUrl: './register.css'

  
})
export class Register {
  title = 'here';
}
