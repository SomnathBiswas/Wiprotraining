import { Component } from '@angular/core';

@Component({
  selector: 'app-hrservice',
  standalone: false,
  templateUrl: './hrservice.html',
  styleUrl: './hrservice.css'
})
export class Hrservice {

}
