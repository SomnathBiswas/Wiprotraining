﻿namespace Interfaces
{
    public interface IDocument
    {
        string GetContent();
    }
}
