﻿namespace Interfaces
{
    public interface IPrintable
    {
        void Print();
    }
}
