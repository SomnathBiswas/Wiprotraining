﻿namespace Interfaces
{
    public interface IReportService
    {
        void GenerateAndSaveReport();
    }
}
