﻿namespace Interfaces
{
    public interface ISavable
    {
        void Save(string path);
    }
}
