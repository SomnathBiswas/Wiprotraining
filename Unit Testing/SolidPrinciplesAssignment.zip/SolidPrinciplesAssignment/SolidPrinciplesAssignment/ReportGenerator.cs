﻿namespace Services
{
    public class ReportGenerator
    {
        public string GenerateReport()
        {
            return "This is a sample report";
        }
    }
}

