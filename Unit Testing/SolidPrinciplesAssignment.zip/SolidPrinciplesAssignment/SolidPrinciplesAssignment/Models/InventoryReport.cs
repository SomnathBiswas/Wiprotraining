﻿namespace Models
{
    public class InventoryReport : Report
    {
        public override string GetContent() => "Inventory Report Content";
    }
}
