﻿namespace Models
{
    public abstract class Report
    {
        public abstract string GetContent();
    }
}
