﻿namespace Models
{
    public class SalesReport : Report
    {
        public override string GetContent() => "Sales Report Content";
    }
}
